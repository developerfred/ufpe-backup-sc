/*
 * Universidade Federal de Pernambuco - UFPE
 * Centro de Inform�tica - CIn
 * Centro Integrado de Tecnologia da Informa��o - CITi
 * Curso de C/C++
 * Instrutor: Allan Lima - adsl@cin.ufpe.br
 *
 * respostaDesafio.c - Resposta ao desafio da primeira aula.
 */

#include <stdio.h>

void showBits(int a) {
	int i, b;

	for (i = ((sizeof(int) * 8) - 1); i > -1; i--) {
		printf("%d", (a >> i) & 1);
	}

	printf("\n");
}


int main() {
	int a;

	showBits(5);
	showBits(20);
	showBits(-6);
	

	return 0;
}


