/*
 * Universidade Federal de Pernambuco - UFPE
 * Centro de Inform�tica - CIn
 * Centro Integrado de Tecnologia da Informa��o - CITi
 * Curso de C/C++
 * Instrutor: Allan Lima - adsl@cin.ufpe.br
 *
 * exemploSwap.c - Mostra como trocar os valores duas vari�veis com apenas uma linha de c�digo
 */


#include <stdio.h>


int main() {

	int a = 10, b = 20;

	printf("Antes: a=%d, b=%d\n", a, b);
	
	a ^= b ^= a ^= b;

	printf("Depois: a=%d, b=%d\n", a, b);
}