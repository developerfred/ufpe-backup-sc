#include <stdio.h>
/*
 * Universidade Federal de Pernambuco - UFPE
 * Centro de Inform�tica - CIn
 * Centro Integrado de Tecnologia da Informa��o - CITi
 * Curso de C/C++
 * Instrutor: Allan Lima - adsl@cin.ufpe.br
 *
 * exemploMatrizes.c - Mostra como utilizar vertores em C.
 */

int main() {
    // Matriz Bidimensional
    int m1[2][2] = { 1, 2, 3, 4 };
    // Outra maneira
    int m2[2][2] = { {1, 2 }, { 3, 4 } };
    // Matriz Tridimensional
    int m3[2][2][2] = { 1, 2, 3, 4, 5, 6, 7, 8 };

    printf("%d\n", m1[1][1]);
    printf("%d\n", m3[1][0][0]);

    return 0;
}
