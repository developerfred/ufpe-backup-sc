/*
 * Universidade Federal de Pernambuco - UFPE
 * Centro de Inform�tica - CIn
 * Centro Integrado de Tecnologia da Informa��o - CITi
 * Curso de C/C++
 * Instrutor: Allan Lima - adsl@cin.ufpe.br
 *
 * exemploVetor.c - Mostra como utilizar vertores em C.
 */

#include <stdio.h>

int main() {
    int numeros[10] = {1, 1};
    int i;

    for (i = 2; i < 10; i++) {
        numeros[i] = numeros[i-1] + numeros[i-2];
    }

    for (i = 0; i < 10; i++) {
        printf("%d\n", numeros[i]);
    }
    
    return 0;
}
