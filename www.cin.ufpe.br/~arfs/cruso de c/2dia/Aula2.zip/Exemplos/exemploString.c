/*
 * Universidade Federal de Pernambuco - UFPE
 * Centro de Inform�tica - CIn
 * Centro Integrado de Tecnologia da Informa��o - CITi
 * Curso de C/C++
 * Instrutor: Allan Lima - adsl@cin.ufpe.br
 *
 * exemploString.c - Mostra como utilizar vertores em C.
 */

#include <stdio.h>

int main() {
    char frase[] = "Eu adoro C";
    char faculdade[5] = {'U', 'F', 'P', 'E', '\0'};
    char centro[4] = "CIn";
    char erro[] = {'U', 'F', 'P', 'E'}; // n�o � uma string


    return 0;
}
